# Bronco Express

URL to github repo: https://github.com/rwhere/BroncoExpress

URL to step 1: https://fz3x5jp27h.execute-api.us-west-2.amazonaws.com/dev/store

URL to step 2: https://fz3x5jp27h.execute-api.us-west-2.amazonaws.com/dev/query